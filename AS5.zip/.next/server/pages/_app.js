/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "__barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!******************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   NavDropdown: () => (/* reexport safe */ _NavDropdown__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_4__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Form */ \"./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Nav */ \"./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavDropdown */ \"./node_modules/react-bootstrap/esm/NavDropdown.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Navbar */ \"./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sRm9ybSxOYXYsTmF2RHJvcGRvd24sTmF2YmFyIT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUM0QztBQUNKO0FBQ0Y7QUFDZ0IiLCJzb3VyY2VzIjpbIkQ6XFxzZW1lc3RlciA0XFxXRUJcXGFzNVxcQXNzaWdubWVudCA1XFxBc3NpZ25tZW50IDVcXG1ldC1tdXNldW0tYXBwXFxub2RlX21vZHVsZXNcXHJlYWN0LWJvb3RzdHJhcFxcZXNtXFxpbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQnV0dG9uIH0gZnJvbSBcIi4vQnV0dG9uXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRm9ybSB9IGZyb20gXCIuL0Zvcm1cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXYgfSBmcm9tIFwiLi9OYXZcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXZEcm9wZG93biB9IGZyb20gXCIuL05hdkRyb3Bkb3duXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2YmFyIH0gZnJvbSBcIi4vTmF2YmFyXCIiXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbMF0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Container */ "./node_modules/react-bootstrap/esm/Container.js");



/***/ }),

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _MainNav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainNav */ \"./components/MainNav.js\");\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\n/*********************************************************************************\r\n*  WEB422 – Assignment 5\r\n*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  \r\n*  No part of this assignment has been copied manually or electronically from any other source\r\n*  (including web sites) or distributed to other students.\r\n* \r\n*  Name: Ranjan Kaduwal Student ID: 126578228 Date: 18th Nov, 2024\r\n*\r\n*\r\n********************************************************************************/ \n\n\nfunction Layout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MainNav__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\Layout.js\",\n                lineNumber: 17,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n                children: children\n            }, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\Layout.js\",\n                lineNumber: 18,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\Layout.js\",\n                lineNumber: 21,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBOzs7Ozs7Ozs7K0VBUytFLEdBQUc7QUFDbEQ7QUFDWTtBQUU3QixTQUFTRSxPQUFPLEVBQUVDLFFBQVEsRUFBRTtJQUN6QyxxQkFDRTs7MEJBQ0UsOERBQUNILGdEQUFPQTs7Ozs7MEJBQ1IsOERBQUNDLHVGQUFTQTswQkFDUEU7Ozs7OzswQkFFSCw4REFBQ0M7Ozs7Ozs7QUFHUCIsInNvdXJjZXMiOlsiRDpcXHNlbWVzdGVyIDRcXFdFQlxcYXM1XFxBc3NpZ25tZW50IDVcXEFzc2lnbm1lbnQgNVxcbWV0LW11c2V1bS1hcHBcXGNvbXBvbmVudHNcXExheW91dC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiogIFdFQjQyMiDigJMgQXNzaWdubWVudCA1XHJcbiogIEkgZGVjbGFyZSB0aGF0IHRoaXMgYXNzaWdubWVudCBpcyBteSBvd24gd29yayBpbiBhY2NvcmRhbmNlIHdpdGggU2VuZWNhIEFjYWRlbWljIFBvbGljeS4gIFxyXG4qICBObyBwYXJ0IG9mIHRoaXMgYXNzaWdubWVudCBoYXMgYmVlbiBjb3BpZWQgbWFudWFsbHkgb3IgZWxlY3Ryb25pY2FsbHkgZnJvbSBhbnkgb3RoZXIgc291cmNlXHJcbiogIChpbmNsdWRpbmcgd2ViIHNpdGVzKSBvciBkaXN0cmlidXRlZCB0byBvdGhlciBzdHVkZW50cy5cclxuKiBcclxuKiAgTmFtZTogUmFuamFuIEthZHV3YWwgU3R1ZGVudCBJRDogMTI2NTc4MjI4IERhdGU6IDE4dGggTm92LCAyMDI0XHJcbipcclxuKlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi8gXHJcbmltcG9ydCBNYWluTmF2IGZyb20gJy4vTWFpbk5hdic7XHJcbmltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJ3JlYWN0LWJvb3RzdHJhcCc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXQoeyBjaGlsZHJlbiB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxNYWluTmF2IC8+XHJcbiAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgPGJyIC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJNYWluTmF2IiwiQ29udGFpbmVyIiwiTGF5b3V0IiwiY2hpbGRyZW4iLCJiciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/Layout.js\n");

/***/ }),

/***/ "./components/MainNav.js":
/*!*******************************!*\
  !*** ./components/MainNav.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MainNav)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!react-bootstrap */ \"__barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/*********************************************************************************\r\n*  WEB422 – Assignment 5\r\n*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  \r\n*  No part of this assignment has been copied manually or electronically from any other source\r\n*  (including web sites) or distributed to other students.\r\n* \r\n*  Name: Ranjan Kaduwal Student ID: 126578228 Date: 18th Nov, 2024\r\n*\r\n*\r\n********************************************************************************/ \n\n\n\nfunction MainNav() {\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const [searchField, setSearchField] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const handleSearch = (event)=>{\n        event.preventDefault();\n        const queryString = `title=true&q=${searchField}`;\n        setIsExpanded(false);\n        router.push(`/artwork?${queryString}`);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar, {\n                bg: \"primary\",\n                variant: \"dark\",\n                fixed: \"top\",\n                expanded: isExpanded,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Brand, {\n                        href: \"/\",\n                        children: \"Ranjan Kaduwal\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                        lineNumber: 30,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Toggle, {\n                        onClick: ()=>setIsExpanded(!isExpanded)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                        lineNumber: 31,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Collapse, {\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav, {\n                                className: \"me-auto\",\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav.Link, {\n                                        href: \"/\",\n                                        active: router.pathname === \"/\",\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Home\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 34,\n                                        columnNumber: 13\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav.Link, {\n                                        href: \"/search\",\n                                        active: router.pathname === \"/search\",\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Advanced Search\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 37,\n                                        columnNumber: 13\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 33,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {\n                                className: \"d-flex\",\n                                onSubmit: handleSearch,\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                        type: \"search\",\n                                        placeholder: \"Search\",\n                                        className: \"me-2\",\n                                        value: searchField,\n                                        onChange: (e)=>setSearchField(e.target.value)\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 42,\n                                        columnNumber: 13\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                                        type: \"submit\",\n                                        variant: \"outline-light\",\n                                        children: \"Search\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 49,\n                                        columnNumber: 13\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 41,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav, {\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.NavDropdown, {\n                                    title: \"Ranjan Kaduwal\",\n                                    id: \"user-dropdown\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.NavDropdown.Item, {\n                                            href: \"/favourites\",\n                                            onClick: ()=>setIsExpanded(false),\n                                            children: \"Favourites\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                            lineNumber: 53,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.NavDropdown.Item, {\n                                            href: \"/history\",\n                                            onClick: ()=>setIsExpanded(false),\n                                            children: \"Search History\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                            lineNumber: 56,\n                                            columnNumber: 15\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 52,\n                                    columnNumber: 13\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 51,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                        lineNumber: 32,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                lineNumber: 29,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                lineNumber: 63,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                lineNumber: 64,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL01haW5OYXYuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7OytFQVMrRSxHQUFHO0FBQ1Q7QUFDakM7QUFDUDtBQUVsQixTQUFTTztJQUN0QixNQUFNLENBQUNDLFlBQVlDLGNBQWMsR0FBR0gsK0NBQVFBLENBQUM7SUFDN0MsTUFBTSxDQUFDSSxhQUFhQyxlQUFlLEdBQUdMLCtDQUFRQSxDQUFDO0lBQy9DLE1BQU1NLFNBQVNQLHNEQUFTQTtJQUV4QixNQUFNUSxlQUFlLENBQUNDO1FBQ3BCQSxNQUFNQyxjQUFjO1FBQ3BCLE1BQU1DLGNBQWMsQ0FBQyxhQUFhLEVBQUVOLGFBQWE7UUFDakRELGNBQWM7UUFDZEcsT0FBT0ssSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFRCxhQUFhO0lBQ3ZDO0lBRUEscUJBQ0U7OzBCQUNFLDhEQUFDaEIsNkdBQU1BO2dCQUFDa0IsSUFBRztnQkFBVUMsU0FBUTtnQkFBT0MsT0FBTTtnQkFBTUMsVUFBVWI7O2tDQUN4RCw4REFBQ1IsNkdBQU1BLENBQUNzQixLQUFLO3dCQUFDQyxNQUFLO2tDQUFJOzs7Ozs7a0NBQ3ZCLDhEQUFDdkIsNkdBQU1BLENBQUN3QixNQUFNO3dCQUFDQyxTQUFTLElBQU1oQixjQUFjLENBQUNEOzs7Ozs7a0NBQzdDLDhEQUFDUiw2R0FBTUEsQ0FBQzBCLFFBQVE7OzBDQUNkLDhEQUFDekIsMEdBQUdBO2dDQUFDMEIsV0FBVTs7a0RBQ2IsOERBQUMxQiwwR0FBR0EsQ0FBQzJCLElBQUk7d0NBQUNMLE1BQUs7d0NBQUlNLFFBQVFqQixPQUFPa0IsUUFBUSxLQUFLO3dDQUFLTCxTQUFTLElBQU1oQixjQUFjO2tEQUFROzs7Ozs7a0RBR3pGLDhEQUFDUiwwR0FBR0EsQ0FBQzJCLElBQUk7d0NBQUNMLE1BQUs7d0NBQVVNLFFBQVFqQixPQUFPa0IsUUFBUSxLQUFLO3dDQUFXTCxTQUFTLElBQU1oQixjQUFjO2tEQUFROzs7Ozs7Ozs7Ozs7MENBSXZHLDhEQUFDTiwyR0FBSUE7Z0NBQUN3QixXQUFVO2dDQUFTSSxVQUFVbEI7O2tEQUNqQyw4REFBQ1YsMkdBQUlBLENBQUM2QixPQUFPO3dDQUNYQyxNQUFLO3dDQUNMQyxhQUFZO3dDQUNaUCxXQUFVO3dDQUNWUSxPQUFPekI7d0NBQ1AwQixVQUFVLENBQUNDLElBQU0xQixlQUFlMEIsRUFBRUMsTUFBTSxDQUFDSCxLQUFLOzs7Ozs7a0RBRWhELDhEQUFDL0IsNkdBQU1BO3dDQUFDNkIsTUFBSzt3Q0FBU2QsU0FBUTtrREFBZ0I7Ozs7Ozs7Ozs7OzswQ0FFaEQsOERBQUNsQiwwR0FBR0E7MENBQ0YsNEVBQUNDLGtIQUFXQTtvQ0FBQ3FDLE9BQU07b0NBQWlCQyxJQUFHOztzREFDckMsOERBQUN0QyxrSEFBV0EsQ0FBQ3VDLElBQUk7NENBQUNsQixNQUFLOzRDQUFjRSxTQUFTLElBQU1oQixjQUFjO3NEQUFROzs7Ozs7c0RBRzFFLDhEQUFDUCxrSEFBV0EsQ0FBQ3VDLElBQUk7NENBQUNsQixNQUFLOzRDQUFXRSxTQUFTLElBQU1oQixjQUFjO3NEQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFPL0UsOERBQUNpQzs7Ozs7MEJBQ0QsOERBQUNBOzs7Ozs7O0FBR1AiLCJzb3VyY2VzIjpbIkQ6XFxzZW1lc3RlciA0XFxXRUJcXGFzNVxcQXNzaWdubWVudCA1XFxBc3NpZ25tZW50IDVcXG1ldC1tdXNldW0tYXBwXFxjb21wb25lbnRzXFxNYWluTmF2LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuKiAgV0VCNDIyIOKAkyBBc3NpZ25tZW50IDVcclxuKiAgSSBkZWNsYXJlIHRoYXQgdGhpcyBhc3NpZ25tZW50IGlzIG15IG93biB3b3JrIGluIGFjY29yZGFuY2Ugd2l0aCBTZW5lY2EgQWNhZGVtaWMgUG9saWN5LiAgXHJcbiogIE5vIHBhcnQgb2YgdGhpcyBhc3NpZ25tZW50IGhhcyBiZWVuIGNvcGllZCBtYW51YWxseSBvciBlbGVjdHJvbmljYWxseSBmcm9tIGFueSBvdGhlciBzb3VyY2VcclxuKiAgKGluY2x1ZGluZyB3ZWIgc2l0ZXMpIG9yIGRpc3RyaWJ1dGVkIHRvIG90aGVyIHN0dWRlbnRzLlxyXG4qIFxyXG4qICBOYW1lOiBSYW5qYW4gS2FkdXdhbCBTdHVkZW50IElEOiAxMjY1NzgyMjggRGF0ZTogMTh0aCBOb3YsIDIwMjRcclxuKlxyXG4qXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqLyBcclxuaW1wb3J0IHsgTmF2YmFyLCBOYXYsIE5hdkRyb3Bkb3duLCBGb3JtLCBCdXR0b24gfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWFpbk5hdigpIHtcclxuICBjb25zdCBbaXNFeHBhbmRlZCwgc2V0SXNFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaEZpZWxkLCBzZXRTZWFyY2hGaWVsZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlYXJjaCA9IChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gYHRpdGxlPXRydWUmcT0ke3NlYXJjaEZpZWxkfWA7XHJcbiAgICBzZXRJc0V4cGFuZGVkKGZhbHNlKTtcclxuICAgIHJvdXRlci5wdXNoKGAvYXJ0d29yaz8ke3F1ZXJ5U3RyaW5nfWApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8TmF2YmFyIGJnPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJkYXJrXCIgZml4ZWQ9XCJ0b3BcIiBleHBhbmRlZD17aXNFeHBhbmRlZH0+XHJcbiAgICAgICAgPE5hdmJhci5CcmFuZCBocmVmPVwiL1wiPlJhbmphbiBLYWR1d2FsPC9OYXZiYXIuQnJhbmQ+XHJcbiAgICAgICAgPE5hdmJhci5Ub2dnbGUgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZCghaXNFeHBhbmRlZCl9IC8+XHJcbiAgICAgICAgPE5hdmJhci5Db2xsYXBzZT5cclxuICAgICAgICAgIDxOYXYgY2xhc3NOYW1lPVwibWUtYXV0b1wiPlxyXG4gICAgICAgICAgICA8TmF2LkxpbmsgaHJlZj1cIi9cIiBhY3RpdmU9e3JvdXRlci5wYXRobmFtZSA9PT0gXCIvXCJ9IG9uQ2xpY2s9eygpID0+IHNldElzRXhwYW5kZWQoZmFsc2UpfT5cclxuICAgICAgICAgICAgICBIb21lXHJcbiAgICAgICAgICAgIDwvTmF2Lkxpbms+XHJcbiAgICAgICAgICAgIDxOYXYuTGluayBocmVmPVwiL3NlYXJjaFwiIGFjdGl2ZT17cm91dGVyLnBhdGhuYW1lID09PSBcIi9zZWFyY2hcIn0gb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9PlxyXG4gICAgICAgICAgICAgIEFkdmFuY2VkIFNlYXJjaFxyXG4gICAgICAgICAgICA8L05hdi5MaW5rPlxyXG4gICAgICAgICAgPC9OYXY+XHJcbiAgICAgICAgICA8Rm9ybSBjbGFzc05hbWU9XCJkLWZsZXhcIiBvblN1Ym1pdD17aGFuZGxlU2VhcmNofT5cclxuICAgICAgICAgICAgPEZvcm0uQ29udHJvbFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzZWFyY2hcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtZS0yXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoRmllbGR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hGaWVsZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJvdXRsaW5lLWxpZ2h0XCI+U2VhcmNoPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0Zvcm0+XHJcbiAgICAgICAgICA8TmF2PlxyXG4gICAgICAgICAgICA8TmF2RHJvcGRvd24gdGl0bGU9XCJSYW5qYW4gS2FkdXdhbFwiIGlkPVwidXNlci1kcm9wZG93blwiPlxyXG4gICAgICAgICAgICAgIDxOYXZEcm9wZG93bi5JdGVtIGhyZWY9XCIvZmF2b3VyaXRlc1wiIG9uQ2xpY2s9eygpID0+IHNldElzRXhwYW5kZWQoZmFsc2UpfT5cclxuICAgICAgICAgICAgICAgIEZhdm91cml0ZXNcclxuICAgICAgICAgICAgICA8L05hdkRyb3Bkb3duLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPE5hdkRyb3Bkb3duLkl0ZW0gaHJlZj1cIi9oaXN0b3J5XCIgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9PlxyXG4gICAgICAgICAgICAgICAgU2VhcmNoIEhpc3RvcnlcclxuICAgICAgICAgICAgICA8L05hdkRyb3Bkb3duLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvTmF2RHJvcGRvd24+XHJcbiAgICAgICAgICA8L05hdj5cclxuICAgICAgICA8L05hdmJhci5Db2xsYXBzZT5cclxuICAgICAgPC9OYXZiYXI+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn0iXSwibmFtZXMiOlsiTmF2YmFyIiwiTmF2IiwiTmF2RHJvcGRvd24iLCJGb3JtIiwiQnV0dG9uIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJNYWluTmF2IiwiaXNFeHBhbmRlZCIsInNldElzRXhwYW5kZWQiLCJzZWFyY2hGaWVsZCIsInNldFNlYXJjaEZpZWxkIiwicm91dGVyIiwiaGFuZGxlU2VhcmNoIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInF1ZXJ5U3RyaW5nIiwicHVzaCIsImJnIiwidmFyaWFudCIsImZpeGVkIiwiZXhwYW5kZWQiLCJCcmFuZCIsImhyZWYiLCJUb2dnbGUiLCJvbkNsaWNrIiwiQ29sbGFwc2UiLCJjbGFzc05hbWUiLCJMaW5rIiwiYWN0aXZlIiwicGF0aG5hbWUiLCJvblN1Ym1pdCIsIkNvbnRyb2wiLCJ0eXBlIiwicGxhY2Vob2xkZXIiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsInRpdGxlIiwiaWQiLCJJdGVtIiwiYnIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/MainNav.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyApp)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ \"./node_modules/bootstrap/dist/css/bootstrap.min.css\");\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Layout */ \"./components/Layout.js\");\n/*********************************************************************************\n*  WEB422 – Assignment 5\n*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  \n*  No part of this assignment has been copied manually or electronically from any other source\n*  (including web sites) or distributed to other students.\n* \n*  Name: Ranjan Kaduwal Student ID: 126578228 Date: 18th Nov, 2024\n*\n*\n********************************************************************************/ \n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_app.js\",\n            lineNumber: 18,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_app.js\",\n        lineNumber: 17,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7Ozs7Ozs7OzsrRUFTK0U7QUFDakM7QUFDZjtBQUNXO0FBRTNCLFNBQVNDLE1BQU0sRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDcEQscUJBQ0UsOERBQUNILDBEQUFNQTtrQkFDTCw0RUFBQ0U7WUFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7OztBQUc5QiIsInNvdXJjZXMiOlsiRDpcXHNlbWVzdGVyIDRcXFdFQlxcYXM1XFxBc3NpZ25tZW50IDVcXEFzc2lnbm1lbnQgNVxcbWV0LW11c2V1bS1hcHBcXHBhZ2VzXFxfYXBwLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiogIFdFQjQyMiDigJMgQXNzaWdubWVudCA1XG4qICBJIGRlY2xhcmUgdGhhdCB0aGlzIGFzc2lnbm1lbnQgaXMgbXkgb3duIHdvcmsgaW4gYWNjb3JkYW5jZSB3aXRoIFNlbmVjYSBBY2FkZW1pYyBQb2xpY3kuICBcbiogIE5vIHBhcnQgb2YgdGhpcyBhc3NpZ25tZW50IGhhcyBiZWVuIGNvcGllZCBtYW51YWxseSBvciBlbGVjdHJvbmljYWxseSBmcm9tIGFueSBvdGhlciBzb3VyY2VcbiogIChpbmNsdWRpbmcgd2ViIHNpdGVzKSBvciBkaXN0cmlidXRlZCB0byBvdGhlciBzdHVkZW50cy5cbiogXG4qICBOYW1lOiBSYW5qYW4gS2FkdXdhbCBTdHVkZW50IElEOiAxMjY1NzgyMjggRGF0ZTogMTh0aCBOb3YsIDIwMjRcbipcbipcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL0xheW91dCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDxMYXlvdXQ+XG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgPC9MYXlvdXQ+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiTGF5b3V0IiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useIsomorphicEffect":
/*!*****************************************************!*\
  !*** external "@restart/hooks/useIsomorphicEffect" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useIsomorphicEffect");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Button":
/*!*************************************!*\
  !*** external "@restart/ui/Button" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Button");

/***/ }),

/***/ "@restart/ui/Dropdown":
/*!***************************************!*\
  !*** external "@restart/ui/Dropdown" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Dropdown");

/***/ }),

/***/ "@restart/ui/DropdownContext":
/*!**********************************************!*\
  !*** external "@restart/ui/DropdownContext" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownContext");

/***/ }),

/***/ "@restart/ui/DropdownItem":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownItem" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownItem");

/***/ }),

/***/ "@restart/ui/DropdownMenu":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownMenu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownMenu");

/***/ }),

/***/ "@restart/ui/DropdownToggle":
/*!*********************************************!*\
  !*** external "@restart/ui/DropdownToggle" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownToggle");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "@restart/ui/utils":
/*!************************************!*\
  !*** external "@restart/ui/utils" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/utils");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "invariant":
/*!****************************!*\
  !*** external "invariant" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("invariant");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "prop-types-extra/lib/all":
/*!*******************************************!*\
  !*** external "prop-types-extra/lib/all" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types-extra/lib/all");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "warning":
/*!**************************!*\
  !*** external "warning" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("warning");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap","vendor-chunks/bootstrap"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();