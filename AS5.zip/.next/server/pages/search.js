/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/search";
exports.ids = ["pages/search"];
exports.modules = {

/***/ "__barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js":
/*!***************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Col: () => (/* reexport safe */ _Col__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Row: () => (/* reexport safe */ _Row__WEBPACK_IMPORTED_MODULE_3__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Col__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Col */ \"./node_modules/react-bootstrap/esm/Col.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Form */ \"./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Row */ \"./node_modules/react-bootstrap/esm/Row.js\");\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sQ29sLEZvcm0sUm93IT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFDNEM7QUFDTjtBQUNFIiwic291cmNlcyI6WyJEOlxcc2VtZXN0ZXIgNFxcV0VCXFxhczVcXEFzc2lnbm1lbnQgNVxcQXNzaWdubWVudCA1XFxtZXQtbXVzZXVtLWFwcFxcbm9kZV9tb2R1bGVzXFxyZWFjdC1ib290c3RyYXBcXGVzbVxcaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEJ1dHRvbiB9IGZyb20gXCIuL0J1dHRvblwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENvbCB9IGZyb20gXCIuL0NvbFwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEZvcm0gfSBmcm9tIFwiLi9Gb3JtXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgUm93IH0gZnJvbSBcIi4vUm93XCIiXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbMF0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!******************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   NavDropdown: () => (/* reexport safe */ _NavDropdown__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_4__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Form */ \"./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Nav */ \"./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavDropdown */ \"./node_modules/react-bootstrap/esm/NavDropdown.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Navbar */ \"./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sRm9ybSxOYXYsTmF2RHJvcGRvd24sTmF2YmFyIT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUM0QztBQUNKO0FBQ0Y7QUFDZ0IiLCJzb3VyY2VzIjpbIkQ6XFxzZW1lc3RlciA0XFxXRUJcXGFzNVxcQXNzaWdubWVudCA1XFxBc3NpZ25tZW50IDVcXG1ldC1tdXNldW0tYXBwXFxub2RlX21vZHVsZXNcXHJlYWN0LWJvb3RzdHJhcFxcZXNtXFxpbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQnV0dG9uIH0gZnJvbSBcIi4vQnV0dG9uXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRm9ybSB9IGZyb20gXCIuL0Zvcm1cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXYgfSBmcm9tIFwiLi9OYXZcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXZEcm9wZG93biB9IGZyb20gXCIuL05hdkRyb3Bkb3duXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2YmFyIH0gZnJvbSBcIi4vTmF2YmFyXCIiXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbMF0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Container */ "./node_modules/react-bootstrap/esm/Container.js");



/***/ }),

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./pages/_document.js\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./pages/_app.js\");\n/* harmony import */ var _pages_search_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\search.js */ \"./pages/search.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_search_js__WEBPACK_IMPORTED_MODULE_5__]);\n_pages_search_js__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'default'));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticProps');\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticPaths');\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'getServerSideProps');\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'config');\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'reportWebVitals');\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticProps');\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticPaths');\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticParams');\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerProps');\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_search_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerSideProps');\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/search\",\n        pathname: \"/search\",\n        // The following aren't used in production.\n        bundlePath: '',\n        filename: ''\n    },\n    components: {\n        // default export might not exist when optimized for data only\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_search_js__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGc2VhcmNoJnByZWZlcnJlZFJlZ2lvbj0mYWJzb2x1dGVQYWdlUGF0aD0uJTJGcGFnZXMlNUNzZWFyY2guanMmYWJzb2x1dGVBcHBQYXRoPXByaXZhdGUtbmV4dC1wYWdlcyUyRl9hcHAmYWJzb2x1dGVEb2N1bWVudFBhdGg9cHJpdmF0ZS1uZXh0LXBhZ2VzJTJGX2RvY3VtZW50Jm1pZGRsZXdhcmVDb25maWdCYXNlNjQ9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQXdGO0FBQ2hDO0FBQ0U7QUFDMUQ7QUFDeUQ7QUFDVjtBQUMvQztBQUMrQztBQUMvQztBQUNBLGlFQUFlLHdFQUFLLENBQUMsNkNBQVEsWUFBWSxFQUFDO0FBQzFDO0FBQ08sdUJBQXVCLHdFQUFLLENBQUMsNkNBQVE7QUFDckMsdUJBQXVCLHdFQUFLLENBQUMsNkNBQVE7QUFDckMsMkJBQTJCLHdFQUFLLENBQUMsNkNBQVE7QUFDekMsZUFBZSx3RUFBSyxDQUFDLDZDQUFRO0FBQzdCLHdCQUF3Qix3RUFBSyxDQUFDLDZDQUFRO0FBQzdDO0FBQ08sZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsaUNBQWlDLHdFQUFLLENBQUMsNkNBQVE7QUFDL0MsZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsb0NBQW9DLHdFQUFLLENBQUMsNkNBQVE7QUFDekQ7QUFDTyx3QkFBd0Isa0dBQWdCO0FBQy9DO0FBQ0EsY0FBYyxrRUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxhQUFhLDhEQUFXO0FBQ3hCLGtCQUFrQixtRUFBZ0I7QUFDbEMsS0FBSztBQUNMLFlBQVk7QUFDWixDQUFDOztBQUVELGlDIiwic291cmNlcyI6WyIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFnZXNSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLW1vZHVsZXMvcGFnZXMvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBob2lzdCB9IGZyb20gXCJuZXh0L2Rpc3QvYnVpbGQvdGVtcGxhdGVzL2hlbHBlcnNcIjtcbi8vIEltcG9ydCB0aGUgYXBwIGFuZCBkb2N1bWVudCBtb2R1bGVzLlxuaW1wb3J0ICogYXMgZG9jdW1lbnQgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fZG9jdW1lbnRcIjtcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwicHJpdmF0ZS1uZXh0LXBhZ2VzL19hcHBcIjtcbi8vIEltcG9ydCB0aGUgdXNlcmxhbmQgY29kZS5cbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIuL3BhZ2VzXFxcXHNlYXJjaC5qc1wiO1xuLy8gUmUtZXhwb3J0IHRoZSBjb21wb25lbnQgKHNob3VsZCBiZSB0aGUgZGVmYXVsdCBleHBvcnQpLlxuZXhwb3J0IGRlZmF1bHQgaG9pc3QodXNlcmxhbmQsICdkZWZhdWx0Jyk7XG4vLyBSZS1leHBvcnQgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAnZ2V0U3RhdGljUHJvcHMnKTtcbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCAnZ2V0U3RhdGljUGF0aHMnKTtcbmV4cG9ydCBjb25zdCBnZXRTZXJ2ZXJTaWRlUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgJ2dldFNlcnZlclNpZGVQcm9wcycpO1xuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCAnY29uZmlnJyk7XG5leHBvcnQgY29uc3QgcmVwb3J0V2ViVml0YWxzID0gaG9pc3QodXNlcmxhbmQsICdyZXBvcnRXZWJWaXRhbHMnKTtcbi8vIFJlLWV4cG9ydCBsZWdhY3kgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U3RhdGljUHJvcHMnKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U3RhdGljUGF0aHMnKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXJhbXMgPSBob2lzdCh1c2VybGFuZCwgJ3Vuc3RhYmxlX2dldFN0YXRpY1BhcmFtcycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclByb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTZXJ2ZXJQcm9wcycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U2VydmVyU2lkZVByb3BzJyk7XG4vLyBDcmVhdGUgYW5kIGV4cG9ydCB0aGUgcm91dGUgbW9kdWxlIHRoYXQgd2lsbCBiZSBjb25zdW1lZC5cbmV4cG9ydCBjb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBQYWdlc1JvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5QQUdFUyxcbiAgICAgICAgcGFnZTogXCIvc2VhcmNoXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9zZWFyY2hcIixcbiAgICAgICAgLy8gVGhlIGZvbGxvd2luZyBhcmVuJ3QgdXNlZCBpbiBwcm9kdWN0aW9uLlxuICAgICAgICBidW5kbGVQYXRoOiAnJyxcbiAgICAgICAgZmlsZW5hbWU6ICcnXG4gICAgfSxcbiAgICBjb21wb25lbnRzOiB7XG4gICAgICAgIC8vIGRlZmF1bHQgZXhwb3J0IG1pZ2h0IG5vdCBleGlzdCB3aGVuIG9wdGltaXplZCBmb3IgZGF0YSBvbmx5XG4gICAgICAgIEFwcDogYXBwLmRlZmF1bHQsXG4gICAgICAgIERvY3VtZW50OiBkb2N1bWVudC5kZWZhdWx0XG4gICAgfSxcbiAgICB1c2VybGFuZFxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhZ2VzLmpzLm1hcCJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _MainNav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainNav */ \"./components/MainNav.js\");\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\n/*********************************************************************************\r\n*  WEB422 – Assignment 5\r\n*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  \r\n*  No part of this assignment has been copied manually or electronically from any other source\r\n*  (including web sites) or distributed to other students.\r\n* \r\n*  Name: Ranjan Kaduwal Student ID: 126578228 Date: 18th Nov, 2024\r\n*\r\n*\r\n********************************************************************************/ \n\n\nfunction Layout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MainNav__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\Layout.js\",\n                lineNumber: 17,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n                children: children\n            }, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\Layout.js\",\n                lineNumber: 18,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\Layout.js\",\n                lineNumber: 21,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBOzs7Ozs7Ozs7K0VBUytFLEdBQUc7QUFDbEQ7QUFDWTtBQUU3QixTQUFTRSxPQUFPLEVBQUVDLFFBQVEsRUFBRTtJQUN6QyxxQkFDRTs7MEJBQ0UsOERBQUNILGdEQUFPQTs7Ozs7MEJBQ1IsOERBQUNDLHVGQUFTQTswQkFDUEU7Ozs7OzswQkFFSCw4REFBQ0M7Ozs7Ozs7QUFHUCIsInNvdXJjZXMiOlsiRDpcXHNlbWVzdGVyIDRcXFdFQlxcYXM1XFxBc3NpZ25tZW50IDVcXEFzc2lnbm1lbnQgNVxcbWV0LW11c2V1bS1hcHBcXGNvbXBvbmVudHNcXExheW91dC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiogIFdFQjQyMiDigJMgQXNzaWdubWVudCA1XHJcbiogIEkgZGVjbGFyZSB0aGF0IHRoaXMgYXNzaWdubWVudCBpcyBteSBvd24gd29yayBpbiBhY2NvcmRhbmNlIHdpdGggU2VuZWNhIEFjYWRlbWljIFBvbGljeS4gIFxyXG4qICBObyBwYXJ0IG9mIHRoaXMgYXNzaWdubWVudCBoYXMgYmVlbiBjb3BpZWQgbWFudWFsbHkgb3IgZWxlY3Ryb25pY2FsbHkgZnJvbSBhbnkgb3RoZXIgc291cmNlXHJcbiogIChpbmNsdWRpbmcgd2ViIHNpdGVzKSBvciBkaXN0cmlidXRlZCB0byBvdGhlciBzdHVkZW50cy5cclxuKiBcclxuKiAgTmFtZTogUmFuamFuIEthZHV3YWwgU3R1ZGVudCBJRDogMTI2NTc4MjI4IERhdGU6IDE4dGggTm92LCAyMDI0XHJcbipcclxuKlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi8gXHJcbmltcG9ydCBNYWluTmF2IGZyb20gJy4vTWFpbk5hdic7XHJcbmltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJ3JlYWN0LWJvb3RzdHJhcCc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXQoeyBjaGlsZHJlbiB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxNYWluTmF2IC8+XHJcbiAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgPGJyIC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJNYWluTmF2IiwiQ29udGFpbmVyIiwiTGF5b3V0IiwiY2hpbGRyZW4iLCJiciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/Layout.js\n");

/***/ }),

/***/ "./components/MainNav.js":
/*!*******************************!*\
  !*** ./components/MainNav.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MainNav)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!react-bootstrap */ \"__barrel_optimize__?names=Button,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/*********************************************************************************\r\n*  WEB422 – Assignment 5\r\n*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  \r\n*  No part of this assignment has been copied manually or electronically from any other source\r\n*  (including web sites) or distributed to other students.\r\n* \r\n*  Name: Ranjan Kaduwal Student ID: 126578228 Date: 18th Nov, 2024\r\n*\r\n*\r\n********************************************************************************/ \n\n\n\nfunction MainNav() {\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const [searchField, setSearchField] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const handleSearch = (event)=>{\n        event.preventDefault();\n        const queryString = `title=true&q=${searchField}`;\n        setIsExpanded(false);\n        router.push(`/artwork?${queryString}`);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar, {\n                bg: \"primary\",\n                variant: \"dark\",\n                fixed: \"top\",\n                expanded: isExpanded,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Brand, {\n                        href: \"/\",\n                        children: \"Ranjan Kaduwal\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                        lineNumber: 30,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Toggle, {\n                        onClick: ()=>setIsExpanded(!isExpanded)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                        lineNumber: 31,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Navbar.Collapse, {\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav, {\n                                className: \"me-auto\",\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav.Link, {\n                                        href: \"/\",\n                                        active: router.pathname === \"/\",\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Home\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 34,\n                                        columnNumber: 13\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav.Link, {\n                                        href: \"/search\",\n                                        active: router.pathname === \"/search\",\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Advanced Search\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 37,\n                                        columnNumber: 13\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 33,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {\n                                className: \"d-flex\",\n                                onSubmit: handleSearch,\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                        type: \"search\",\n                                        placeholder: \"Search\",\n                                        className: \"me-2\",\n                                        value: searchField,\n                                        onChange: (e)=>setSearchField(e.target.value)\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 42,\n                                        columnNumber: 13\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                                        type: \"submit\",\n                                        variant: \"outline-light\",\n                                        children: \"Search\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 49,\n                                        columnNumber: 13\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 41,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Nav, {\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.NavDropdown, {\n                                    title: \"Ranjan Kaduwal\",\n                                    id: \"user-dropdown\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.NavDropdown.Item, {\n                                            href: \"/favourites\",\n                                            onClick: ()=>setIsExpanded(false),\n                                            children: \"Favourites\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                            lineNumber: 53,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.NavDropdown.Item, {\n                                            href: \"/history\",\n                                            onClick: ()=>setIsExpanded(false),\n                                            children: \"Search History\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                            lineNumber: 56,\n                                            columnNumber: 15\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 52,\n                                    columnNumber: 13\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 51,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                        lineNumber: 32,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                lineNumber: 29,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                lineNumber: 63,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\components\\\\MainNav.js\",\n                lineNumber: 64,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL01haW5OYXYuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7OytFQVMrRSxHQUFHO0FBQ1Q7QUFDakM7QUFDUDtBQUVsQixTQUFTTztJQUN0QixNQUFNLENBQUNDLFlBQVlDLGNBQWMsR0FBR0gsK0NBQVFBLENBQUM7SUFDN0MsTUFBTSxDQUFDSSxhQUFhQyxlQUFlLEdBQUdMLCtDQUFRQSxDQUFDO0lBQy9DLE1BQU1NLFNBQVNQLHNEQUFTQTtJQUV4QixNQUFNUSxlQUFlLENBQUNDO1FBQ3BCQSxNQUFNQyxjQUFjO1FBQ3BCLE1BQU1DLGNBQWMsQ0FBQyxhQUFhLEVBQUVOLGFBQWE7UUFDakRELGNBQWM7UUFDZEcsT0FBT0ssSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFRCxhQUFhO0lBQ3ZDO0lBRUEscUJBQ0U7OzBCQUNFLDhEQUFDaEIsNkdBQU1BO2dCQUFDa0IsSUFBRztnQkFBVUMsU0FBUTtnQkFBT0MsT0FBTTtnQkFBTUMsVUFBVWI7O2tDQUN4RCw4REFBQ1IsNkdBQU1BLENBQUNzQixLQUFLO3dCQUFDQyxNQUFLO2tDQUFJOzs7Ozs7a0NBQ3ZCLDhEQUFDdkIsNkdBQU1BLENBQUN3QixNQUFNO3dCQUFDQyxTQUFTLElBQU1oQixjQUFjLENBQUNEOzs7Ozs7a0NBQzdDLDhEQUFDUiw2R0FBTUEsQ0FBQzBCLFFBQVE7OzBDQUNkLDhEQUFDekIsMEdBQUdBO2dDQUFDMEIsV0FBVTs7a0RBQ2IsOERBQUMxQiwwR0FBR0EsQ0FBQzJCLElBQUk7d0NBQUNMLE1BQUs7d0NBQUlNLFFBQVFqQixPQUFPa0IsUUFBUSxLQUFLO3dDQUFLTCxTQUFTLElBQU1oQixjQUFjO2tEQUFROzs7Ozs7a0RBR3pGLDhEQUFDUiwwR0FBR0EsQ0FBQzJCLElBQUk7d0NBQUNMLE1BQUs7d0NBQVVNLFFBQVFqQixPQUFPa0IsUUFBUSxLQUFLO3dDQUFXTCxTQUFTLElBQU1oQixjQUFjO2tEQUFROzs7Ozs7Ozs7Ozs7MENBSXZHLDhEQUFDTiwyR0FBSUE7Z0NBQUN3QixXQUFVO2dDQUFTSSxVQUFVbEI7O2tEQUNqQyw4REFBQ1YsMkdBQUlBLENBQUM2QixPQUFPO3dDQUNYQyxNQUFLO3dDQUNMQyxhQUFZO3dDQUNaUCxXQUFVO3dDQUNWUSxPQUFPekI7d0NBQ1AwQixVQUFVLENBQUNDLElBQU0xQixlQUFlMEIsRUFBRUMsTUFBTSxDQUFDSCxLQUFLOzs7Ozs7a0RBRWhELDhEQUFDL0IsNkdBQU1BO3dDQUFDNkIsTUFBSzt3Q0FBU2QsU0FBUTtrREFBZ0I7Ozs7Ozs7Ozs7OzswQ0FFaEQsOERBQUNsQiwwR0FBR0E7MENBQ0YsNEVBQUNDLGtIQUFXQTtvQ0FBQ3FDLE9BQU07b0NBQWlCQyxJQUFHOztzREFDckMsOERBQUN0QyxrSEFBV0EsQ0FBQ3VDLElBQUk7NENBQUNsQixNQUFLOzRDQUFjRSxTQUFTLElBQU1oQixjQUFjO3NEQUFROzs7Ozs7c0RBRzFFLDhEQUFDUCxrSEFBV0EsQ0FBQ3VDLElBQUk7NENBQUNsQixNQUFLOzRDQUFXRSxTQUFTLElBQU1oQixjQUFjO3NEQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFPL0UsOERBQUNpQzs7Ozs7MEJBQ0QsOERBQUNBOzs7Ozs7O0FBR1AiLCJzb3VyY2VzIjpbIkQ6XFxzZW1lc3RlciA0XFxXRUJcXGFzNVxcQXNzaWdubWVudCA1XFxBc3NpZ25tZW50IDVcXG1ldC1tdXNldW0tYXBwXFxjb21wb25lbnRzXFxNYWluTmF2LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuKiAgV0VCNDIyIOKAkyBBc3NpZ25tZW50IDVcclxuKiAgSSBkZWNsYXJlIHRoYXQgdGhpcyBhc3NpZ25tZW50IGlzIG15IG93biB3b3JrIGluIGFjY29yZGFuY2Ugd2l0aCBTZW5lY2EgQWNhZGVtaWMgUG9saWN5LiAgXHJcbiogIE5vIHBhcnQgb2YgdGhpcyBhc3NpZ25tZW50IGhhcyBiZWVuIGNvcGllZCBtYW51YWxseSBvciBlbGVjdHJvbmljYWxseSBmcm9tIGFueSBvdGhlciBzb3VyY2VcclxuKiAgKGluY2x1ZGluZyB3ZWIgc2l0ZXMpIG9yIGRpc3RyaWJ1dGVkIHRvIG90aGVyIHN0dWRlbnRzLlxyXG4qIFxyXG4qICBOYW1lOiBSYW5qYW4gS2FkdXdhbCBTdHVkZW50IElEOiAxMjY1NzgyMjggRGF0ZTogMTh0aCBOb3YsIDIwMjRcclxuKlxyXG4qXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqLyBcclxuaW1wb3J0IHsgTmF2YmFyLCBOYXYsIE5hdkRyb3Bkb3duLCBGb3JtLCBCdXR0b24gfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWFpbk5hdigpIHtcclxuICBjb25zdCBbaXNFeHBhbmRlZCwgc2V0SXNFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaEZpZWxkLCBzZXRTZWFyY2hGaWVsZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlYXJjaCA9IChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gYHRpdGxlPXRydWUmcT0ke3NlYXJjaEZpZWxkfWA7XHJcbiAgICBzZXRJc0V4cGFuZGVkKGZhbHNlKTtcclxuICAgIHJvdXRlci5wdXNoKGAvYXJ0d29yaz8ke3F1ZXJ5U3RyaW5nfWApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8TmF2YmFyIGJnPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJkYXJrXCIgZml4ZWQ9XCJ0b3BcIiBleHBhbmRlZD17aXNFeHBhbmRlZH0+XHJcbiAgICAgICAgPE5hdmJhci5CcmFuZCBocmVmPVwiL1wiPlJhbmphbiBLYWR1d2FsPC9OYXZiYXIuQnJhbmQ+XHJcbiAgICAgICAgPE5hdmJhci5Ub2dnbGUgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZCghaXNFeHBhbmRlZCl9IC8+XHJcbiAgICAgICAgPE5hdmJhci5Db2xsYXBzZT5cclxuICAgICAgICAgIDxOYXYgY2xhc3NOYW1lPVwibWUtYXV0b1wiPlxyXG4gICAgICAgICAgICA8TmF2LkxpbmsgaHJlZj1cIi9cIiBhY3RpdmU9e3JvdXRlci5wYXRobmFtZSA9PT0gXCIvXCJ9IG9uQ2xpY2s9eygpID0+IHNldElzRXhwYW5kZWQoZmFsc2UpfT5cclxuICAgICAgICAgICAgICBIb21lXHJcbiAgICAgICAgICAgIDwvTmF2Lkxpbms+XHJcbiAgICAgICAgICAgIDxOYXYuTGluayBocmVmPVwiL3NlYXJjaFwiIGFjdGl2ZT17cm91dGVyLnBhdGhuYW1lID09PSBcIi9zZWFyY2hcIn0gb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9PlxyXG4gICAgICAgICAgICAgIEFkdmFuY2VkIFNlYXJjaFxyXG4gICAgICAgICAgICA8L05hdi5MaW5rPlxyXG4gICAgICAgICAgPC9OYXY+XHJcbiAgICAgICAgICA8Rm9ybSBjbGFzc05hbWU9XCJkLWZsZXhcIiBvblN1Ym1pdD17aGFuZGxlU2VhcmNofT5cclxuICAgICAgICAgICAgPEZvcm0uQ29udHJvbFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzZWFyY2hcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtZS0yXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoRmllbGR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hGaWVsZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJvdXRsaW5lLWxpZ2h0XCI+U2VhcmNoPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0Zvcm0+XHJcbiAgICAgICAgICA8TmF2PlxyXG4gICAgICAgICAgICA8TmF2RHJvcGRvd24gdGl0bGU9XCJSYW5qYW4gS2FkdXdhbFwiIGlkPVwidXNlci1kcm9wZG93blwiPlxyXG4gICAgICAgICAgICAgIDxOYXZEcm9wZG93bi5JdGVtIGhyZWY9XCIvZmF2b3VyaXRlc1wiIG9uQ2xpY2s9eygpID0+IHNldElzRXhwYW5kZWQoZmFsc2UpfT5cclxuICAgICAgICAgICAgICAgIEZhdm91cml0ZXNcclxuICAgICAgICAgICAgICA8L05hdkRyb3Bkb3duLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPE5hdkRyb3Bkb3duLkl0ZW0gaHJlZj1cIi9oaXN0b3J5XCIgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9PlxyXG4gICAgICAgICAgICAgICAgU2VhcmNoIEhpc3RvcnlcclxuICAgICAgICAgICAgICA8L05hdkRyb3Bkb3duLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvTmF2RHJvcGRvd24+XHJcbiAgICAgICAgICA8L05hdj5cclxuICAgICAgICA8L05hdmJhci5Db2xsYXBzZT5cclxuICAgICAgPC9OYXZiYXI+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn0iXSwibmFtZXMiOlsiTmF2YmFyIiwiTmF2IiwiTmF2RHJvcGRvd24iLCJGb3JtIiwiQnV0dG9uIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJNYWluTmF2IiwiaXNFeHBhbmRlZCIsInNldElzRXhwYW5kZWQiLCJzZWFyY2hGaWVsZCIsInNldFNlYXJjaEZpZWxkIiwicm91dGVyIiwiaGFuZGxlU2VhcmNoIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInF1ZXJ5U3RyaW5nIiwicHVzaCIsImJnIiwidmFyaWFudCIsImZpeGVkIiwiZXhwYW5kZWQiLCJCcmFuZCIsImhyZWYiLCJUb2dnbGUiLCJvbkNsaWNrIiwiQ29sbGFwc2UiLCJjbGFzc05hbWUiLCJMaW5rIiwiYWN0aXZlIiwicGF0aG5hbWUiLCJvblN1Ym1pdCIsIkNvbnRyb2wiLCJ0eXBlIiwicGxhY2Vob2xkZXIiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsInRpdGxlIiwiaWQiLCJJdGVtIiwiYnIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/MainNav.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyApp)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ \"./node_modules/bootstrap/dist/css/bootstrap.min.css\");\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Layout */ \"./components/Layout.js\");\n/*********************************************************************************\n*  WEB422 – Assignment 5\n*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  \n*  No part of this assignment has been copied manually or electronically from any other source\n*  (including web sites) or distributed to other students.\n* \n*  Name: Ranjan Kaduwal Student ID: 126578228 Date: 18th Nov, 2024\n*\n*\n********************************************************************************/ \n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_app.js\",\n            lineNumber: 18,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_app.js\",\n        lineNumber: 17,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7Ozs7Ozs7OzsrRUFTK0U7QUFDakM7QUFDZjtBQUNXO0FBRTNCLFNBQVNDLE1BQU0sRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDcEQscUJBQ0UsOERBQUNILDBEQUFNQTtrQkFDTCw0RUFBQ0U7WUFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7OztBQUc5QiIsInNvdXJjZXMiOlsiRDpcXHNlbWVzdGVyIDRcXFdFQlxcYXM1XFxBc3NpZ25tZW50IDVcXEFzc2lnbm1lbnQgNVxcbWV0LW11c2V1bS1hcHBcXHBhZ2VzXFxfYXBwLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiogIFdFQjQyMiDigJMgQXNzaWdubWVudCA1XG4qICBJIGRlY2xhcmUgdGhhdCB0aGlzIGFzc2lnbm1lbnQgaXMgbXkgb3duIHdvcmsgaW4gYWNjb3JkYW5jZSB3aXRoIFNlbmVjYSBBY2FkZW1pYyBQb2xpY3kuICBcbiogIE5vIHBhcnQgb2YgdGhpcyBhc3NpZ25tZW50IGhhcyBiZWVuIGNvcGllZCBtYW51YWxseSBvciBlbGVjdHJvbmljYWxseSBmcm9tIGFueSBvdGhlciBzb3VyY2VcbiogIChpbmNsdWRpbmcgd2ViIHNpdGVzKSBvciBkaXN0cmlidXRlZCB0byBvdGhlciBzdHVkZW50cy5cbiogXG4qICBOYW1lOiBSYW5qYW4gS2FkdXdhbCBTdHVkZW50IElEOiAxMjY1NzgyMjggRGF0ZTogMTh0aCBOb3YsIDIwMjRcbipcbipcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL0xheW91dCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDxMYXlvdXQ+XG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgPC9MYXlvdXQ+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiTGF5b3V0IiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./pages/_document.js":
/*!****************************!*\
  !*** ./pages/_document.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_document.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_document.js\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_document.js\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_document.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\_document.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZG9jdW1lbnQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQTZEO0FBRTlDLFNBQVNJO0lBQ3RCLHFCQUNFLDhEQUFDSiwrQ0FBSUE7UUFBQ0ssTUFBSzs7MEJBQ1QsOERBQUNKLCtDQUFJQTs7Ozs7MEJBQ0wsOERBQUNLOztrQ0FDQyw4REFBQ0osK0NBQUlBOzs7OztrQ0FDTCw4REFBQ0MscURBQVVBOzs7Ozs7Ozs7Ozs7Ozs7OztBQUluQiIsInNvdXJjZXMiOlsiRDpcXHNlbWVzdGVyIDRcXFdFQlxcYXM1XFxBc3NpZ25tZW50IDVcXEFzc2lnbm1lbnQgNVxcbWV0LW11c2V1bS1hcHBcXHBhZ2VzXFxfZG9jdW1lbnQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSHRtbCwgSGVhZCwgTWFpbiwgTmV4dFNjcmlwdCB9IGZyb20gXCJuZXh0L2RvY3VtZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERvY3VtZW50KCkge1xuICByZXR1cm4gKFxuICAgIDxIdG1sIGxhbmc9XCJlblwiPlxuICAgICAgPEhlYWQgLz5cbiAgICAgIDxib2R5PlxuICAgICAgICA8TWFpbiAvPlxuICAgICAgICA8TmV4dFNjcmlwdCAvPlxuICAgICAgPC9ib2R5PlxuICAgIDwvSHRtbD5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJIdG1sIiwiSGVhZCIsIk1haW4iLCJOZXh0U2NyaXB0IiwiRG9jdW1lbnQiLCJsYW5nIiwiYm9keSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_document.js\n");

/***/ }),

/***/ "./pages/search.js":
/*!*************************!*\
  !*** ./pages/search.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ AdvancedSearch)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-hook-form */ \"react-hook-form\");\n/* harmony import */ var _barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Col,Form,Row!=!react-bootstrap */ \"__barrel_optimize__?names=Button,Col,Form,Row!=!./node_modules/react-bootstrap/esm/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);\nreact_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n/*********************************************************************************\r\n*  WEB422 – Assignment 4\r\n*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  \r\n*  No part of this assignment has been copied manually or electronically from any other source\r\n*  (including web sites) or distributed to other students.\r\n* \r\n*  Name: Ranjan Kaduwal Student ID: 126578228 Date: 12th November, 2024\r\n*\r\n********************************************************************************/ \n\n\n\nfunction AdvancedSearch() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const { register, handleSubmit } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)();\n    const onSubmit = (data)=>{\n        let queryString = `searchBy=${data.searchBy}&q=${data.q}`;\n        if (data.geoLocation) queryString += `&geoLocation=${data.geoLocation}`;\n        if (data.medium) queryString += `&medium=${data.medium}`;\n        if (data.isOnView) queryString += `&isOnView=true`;\n        if (data.isHighlight) queryString += `&isHighlight=true`;\n        router.push(`/artwork?${queryString}`);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"p-4\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h2\", {\n                children: \"Advanced Search\"\n            }, void 0, false, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                lineNumber: 30,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {\n                onSubmit: handleSubmit(onSubmit),\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                        controlId: \"searchQuery\",\n                        className: \"mb-3\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                children: \"Search Query\"\n                            }, void 0, false, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                lineNumber: 33,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                type: \"text\",\n                                placeholder: \"Enter search query\",\n                                ...register(\"q\", {\n                                    required: true\n                                })\n                            }, void 0, false, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                lineNumber: 34,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                        lineNumber: 32,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Row, {\n                        className: \"mb-3\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                                    controlId: \"searchBy\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                            children: \"Search By\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 44,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Select, {\n                                            ...register(\"searchBy\"),\n                                            children: [\n                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"option\", {\n                                                    value: \"title\",\n                                                    children: \"Title\"\n                                                }, void 0, false, {\n                                                    fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                                    lineNumber: 46,\n                                                    columnNumber: 17\n                                                }, this),\n                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"option\", {\n                                                    value: \"tags\",\n                                                    children: \"Tags\"\n                                                }, void 0, false, {\n                                                    fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                                    lineNumber: 47,\n                                                    columnNumber: 17\n                                                }, this)\n                                            ]\n                                        }, void 0, true, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 45,\n                                            columnNumber: 15\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                    lineNumber: 43,\n                                    columnNumber: 13\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                lineNumber: 42,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                                    controlId: \"geoLocation\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                            children: \"Geo Location\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 54,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                            type: \"text\",\n                                            placeholder: \"Enter geo location\",\n                                            ...register(\"geoLocation\")\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 55,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Text, {\n                                            className: \"text-muted\",\n                                            children: 'Case Sensitive String (e.g., \"Europe\", \"France\", \"Paris\"), separated by |.'\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 60,\n                                            columnNumber: 15\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                    lineNumber: 53,\n                                    columnNumber: 13\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                lineNumber: 52,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                                    controlId: \"medium\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Label, {\n                                            children: \"Medium\"\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 68,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Control, {\n                                            type: \"text\",\n                                            placeholder: \"Enter medium\",\n                                            ...register(\"medium\")\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 69,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Text, {\n                                            className: \"text-muted\",\n                                            children: 'Case Sensitive String (e.g., \"Paintings\", \"Sculpture\"), separated by |.'\n                                        }, void 0, false, {\n                                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                            lineNumber: 74,\n                                            columnNumber: 15\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                    lineNumber: 67,\n                                    columnNumber: 13\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                                lineNumber: 66,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                        lineNumber: 41,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                        controlId: \"highlight\",\n                        className: \"mb-3\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Check, {\n                            type: \"checkbox\",\n                            label: \"Highlighted\",\n                            ...register(\"isHighlight\")\n                        }, void 0, false, {\n                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                            lineNumber: 82,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                        lineNumber: 81,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Group, {\n                        controlId: \"onView\",\n                        className: \"mb-3\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form.Check, {\n                            type: \"checkbox\",\n                            label: \"Currently on View\",\n                            ...register(\"isOnView\")\n                        }, void 0, false, {\n                            fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                            lineNumber: 90,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                        lineNumber: 89,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Col_Form_Row_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                        variant: \"primary\",\n                        type: \"submit\",\n                        children: \"Submit\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                        lineNumber: 97,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n                lineNumber: 31,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\semester 4\\\\WEB\\\\as5\\\\Assignment 5\\\\Assignment 5\\\\met-museum-app\\\\pages\\\\search.js\",\n        lineNumber: 29,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zZWFyY2guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUFBOzs7Ozs7OzsrRUFRK0UsR0FBRztBQUMxQztBQUNFO0FBQ2U7QUFFMUMsU0FBU007SUFDdEIsTUFBTUMsU0FBU1Asc0RBQVNBO0lBQ3hCLE1BQU0sRUFBRVEsUUFBUSxFQUFFQyxZQUFZLEVBQUUsR0FBR1Isd0RBQU9BO0lBRTFDLE1BQU1TLFdBQVcsQ0FBQ0M7UUFDaEIsSUFBSUMsY0FBYyxDQUFDLFNBQVMsRUFBRUQsS0FBS0UsUUFBUSxDQUFDLEdBQUcsRUFBRUYsS0FBS0csQ0FBQyxFQUFFO1FBQ3pELElBQUlILEtBQUtJLFdBQVcsRUFBRUgsZUFBZSxDQUFDLGFBQWEsRUFBRUQsS0FBS0ksV0FBVyxFQUFFO1FBQ3ZFLElBQUlKLEtBQUtLLE1BQU0sRUFBRUosZUFBZSxDQUFDLFFBQVEsRUFBRUQsS0FBS0ssTUFBTSxFQUFFO1FBQ3hELElBQUlMLEtBQUtNLFFBQVEsRUFBRUwsZUFBZSxDQUFDLGNBQWMsQ0FBQztRQUNsRCxJQUFJRCxLQUFLTyxXQUFXLEVBQUVOLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztRQUV4REwsT0FBT1ksSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFUCxhQUFhO0lBQ3ZDO0lBRUEscUJBQ0UsOERBQUNRO1FBQUlDLFdBQVU7OzBCQUNiLDhEQUFDQzswQkFBRzs7Ozs7OzBCQUNKLDhEQUFDbEIsNEZBQUlBO2dCQUFDTSxVQUFVRCxhQUFhQzs7a0NBQzNCLDhEQUFDTiw0RkFBSUEsQ0FBQ21CLEtBQUs7d0JBQUNDLFdBQVU7d0JBQWNILFdBQVU7OzBDQUM1Qyw4REFBQ2pCLDRGQUFJQSxDQUFDcUIsS0FBSzswQ0FBQzs7Ozs7OzBDQUNaLDhEQUFDckIsNEZBQUlBLENBQUNzQixPQUFPO2dDQUNYQyxNQUFLO2dDQUNMQyxhQUFZO2dDQUNYLEdBQUdwQixTQUFTLEtBQUs7b0NBQUVxQixVQUFVO2dDQUFLLEVBQUU7Ozs7Ozs7Ozs7OztrQ0FJekMsOERBQUMzQiwyRkFBR0E7d0JBQUNtQixXQUFVOzswQ0FDYiw4REFBQ2xCLDJGQUFHQTswQ0FDRiw0RUFBQ0MsNEZBQUlBLENBQUNtQixLQUFLO29DQUFDQyxXQUFVOztzREFDcEIsOERBQUNwQiw0RkFBSUEsQ0FBQ3FCLEtBQUs7c0RBQUM7Ozs7OztzREFDWiw4REFBQ3JCLDRGQUFJQSxDQUFDMEIsTUFBTTs0Q0FBRSxHQUFHdEIsU0FBUyxXQUFXOzs4REFDbkMsOERBQUN1QjtvREFBT0MsT0FBTTs4REFBUTs7Ozs7OzhEQUN0Qiw4REFBQ0Q7b0RBQU9DLE9BQU07OERBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUszQiw4REFBQzdCLDJGQUFHQTswQ0FDRiw0RUFBQ0MsNEZBQUlBLENBQUNtQixLQUFLO29DQUFDQyxXQUFVOztzREFDcEIsOERBQUNwQiw0RkFBSUEsQ0FBQ3FCLEtBQUs7c0RBQUM7Ozs7OztzREFDWiw4REFBQ3JCLDRGQUFJQSxDQUFDc0IsT0FBTzs0Q0FDWEMsTUFBSzs0Q0FDTEMsYUFBWTs0Q0FDWCxHQUFHcEIsU0FBUyxjQUFjOzs7Ozs7c0RBRTdCLDhEQUFDSiw0RkFBSUEsQ0FBQzZCLElBQUk7NENBQUNaLFdBQVU7c0RBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQU10Qyw4REFBQ2xCLDJGQUFHQTswQ0FDRiw0RUFBQ0MsNEZBQUlBLENBQUNtQixLQUFLO29DQUFDQyxXQUFVOztzREFDcEIsOERBQUNwQiw0RkFBSUEsQ0FBQ3FCLEtBQUs7c0RBQUM7Ozs7OztzREFDWiw4REFBQ3JCLDRGQUFJQSxDQUFDc0IsT0FBTzs0Q0FDWEMsTUFBSzs0Q0FDTEMsYUFBWTs0Q0FDWCxHQUFHcEIsU0FBUyxTQUFTOzs7Ozs7c0RBRXhCLDhEQUFDSiw0RkFBSUEsQ0FBQzZCLElBQUk7NENBQUNaLFdBQVU7c0RBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tDQU94Qyw4REFBQ2pCLDRGQUFJQSxDQUFDbUIsS0FBSzt3QkFBQ0MsV0FBVTt3QkFBWUgsV0FBVTtrQ0FDMUMsNEVBQUNqQiw0RkFBSUEsQ0FBQzhCLEtBQUs7NEJBQ1RQLE1BQUs7NEJBQ0xRLE9BQU07NEJBQ0wsR0FBRzNCLFNBQVMsY0FBYzs7Ozs7Ozs7Ozs7a0NBSS9CLDhEQUFDSiw0RkFBSUEsQ0FBQ21CLEtBQUs7d0JBQUNDLFdBQVU7d0JBQVNILFdBQVU7a0NBQ3ZDLDRFQUFDakIsNEZBQUlBLENBQUM4QixLQUFLOzRCQUNUUCxNQUFLOzRCQUNMUSxPQUFNOzRCQUNMLEdBQUczQixTQUFTLFdBQVc7Ozs7Ozs7Ozs7O2tDQUk1Qiw4REFBQ0gsOEZBQU1BO3dCQUFDK0IsU0FBUTt3QkFBVVQsTUFBSztrQ0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTWhEIiwic291cmNlcyI6WyJEOlxcc2VtZXN0ZXIgNFxcV0VCXFxhczVcXEFzc2lnbm1lbnQgNVxcQXNzaWdubWVudCA1XFxtZXQtbXVzZXVtLWFwcFxccGFnZXNcXHNlYXJjaC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiogIFdFQjQyMiDigJMgQXNzaWdubWVudCA0XHJcbiogIEkgZGVjbGFyZSB0aGF0IHRoaXMgYXNzaWdubWVudCBpcyBteSBvd24gd29yayBpbiBhY2NvcmRhbmNlIHdpdGggU2VuZWNhIEFjYWRlbWljIFBvbGljeS4gIFxyXG4qICBObyBwYXJ0IG9mIHRoaXMgYXNzaWdubWVudCBoYXMgYmVlbiBjb3BpZWQgbWFudWFsbHkgb3IgZWxlY3Ryb25pY2FsbHkgZnJvbSBhbnkgb3RoZXIgc291cmNlXHJcbiogIChpbmNsdWRpbmcgd2ViIHNpdGVzKSBvciBkaXN0cmlidXRlZCB0byBvdGhlciBzdHVkZW50cy5cclxuKiBcclxuKiAgTmFtZTogUmFuamFuIEthZHV3YWwgU3R1ZGVudCBJRDogMTI2NTc4MjI4IERhdGU6IDEydGggTm92ZW1iZXIsIDIwMjRcclxuKlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi8gXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSc7XHJcbmltcG9ydCB7IFJvdywgQ29sLCBGb3JtLCBCdXR0b24gfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQWR2YW5jZWRTZWFyY2goKSB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0IH0gPSB1c2VGb3JtKCk7XHJcblxyXG4gIGNvbnN0IG9uU3VibWl0ID0gKGRhdGEpID0+IHtcclxuICAgIGxldCBxdWVyeVN0cmluZyA9IGBzZWFyY2hCeT0ke2RhdGEuc2VhcmNoQnl9JnE9JHtkYXRhLnF9YDtcclxuICAgIGlmIChkYXRhLmdlb0xvY2F0aW9uKSBxdWVyeVN0cmluZyArPSBgJmdlb0xvY2F0aW9uPSR7ZGF0YS5nZW9Mb2NhdGlvbn1gO1xyXG4gICAgaWYgKGRhdGEubWVkaXVtKSBxdWVyeVN0cmluZyArPSBgJm1lZGl1bT0ke2RhdGEubWVkaXVtfWA7XHJcbiAgICBpZiAoZGF0YS5pc09uVmlldykgcXVlcnlTdHJpbmcgKz0gYCZpc09uVmlldz10cnVlYDtcclxuICAgIGlmIChkYXRhLmlzSGlnaGxpZ2h0KSBxdWVyeVN0cmluZyArPSBgJmlzSGlnaGxpZ2h0PXRydWVgO1xyXG5cclxuICAgIHJvdXRlci5wdXNoKGAvYXJ0d29yaz8ke3F1ZXJ5U3RyaW5nfWApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICA8aDI+QWR2YW5jZWQgU2VhcmNoPC9oMj5cclxuICAgICAgPEZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxyXG4gICAgICAgIDxGb3JtLkdyb3VwIGNvbnRyb2xJZD1cInNlYXJjaFF1ZXJ5XCIgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgPEZvcm0uTGFiZWw+U2VhcmNoIFF1ZXJ5PC9Gb3JtLkxhYmVsPlxyXG4gICAgICAgICAgPEZvcm0uQ29udHJvbFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgc2VhcmNoIHF1ZXJ5XCJcclxuICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwicVwiLCB7IHJlcXVpcmVkOiB0cnVlIH0pfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0Zvcm0uR3JvdXA+XHJcblxyXG4gICAgICAgIDxSb3cgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgPENvbD5cclxuICAgICAgICAgICAgPEZvcm0uR3JvdXAgY29udHJvbElkPVwic2VhcmNoQnlcIj5cclxuICAgICAgICAgICAgICA8Rm9ybS5MYWJlbD5TZWFyY2ggQnk8L0Zvcm0uTGFiZWw+XHJcbiAgICAgICAgICAgICAgPEZvcm0uU2VsZWN0IHsuLi5yZWdpc3RlcihcInNlYXJjaEJ5XCIpfT5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0aXRsZVwiPlRpdGxlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGFnc1wiPlRhZ3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8L0Zvcm0uU2VsZWN0PlxyXG4gICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XHJcbiAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICA8Q29sPlxyXG4gICAgICAgICAgICA8Rm9ybS5Hcm91cCBjb250cm9sSWQ9XCJnZW9Mb2NhdGlvblwiPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkxhYmVsPkdlbyBMb2NhdGlvbjwvRm9ybS5MYWJlbD5cclxuICAgICAgICAgICAgICA8Rm9ybS5Db250cm9sXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGdlbyBsb2NhdGlvblwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJnZW9Mb2NhdGlvblwiKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxGb3JtLlRleHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgQ2FzZSBTZW5zaXRpdmUgU3RyaW5nIChlLmcuLCBcIkV1cm9wZVwiLCBcIkZyYW5jZVwiLCBcIlBhcmlzXCIpLCBzZXBhcmF0ZWQgYnkgfC5cclxuICAgICAgICAgICAgICA8L0Zvcm0uVGV4dD5cclxuICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxyXG4gICAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgICAgPENvbD5cclxuICAgICAgICAgICAgPEZvcm0uR3JvdXAgY29udHJvbElkPVwibWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgPEZvcm0uTGFiZWw+TWVkaXVtPC9Gb3JtLkxhYmVsPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkNvbnRyb2xcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcIm1lZGl1bVwiKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxGb3JtLlRleHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgQ2FzZSBTZW5zaXRpdmUgU3RyaW5nIChlLmcuLCBcIlBhaW50aW5nc1wiLCBcIlNjdWxwdHVyZVwiKSwgc2VwYXJhdGVkIGJ5IHwuXHJcbiAgICAgICAgICAgICAgPC9Gb3JtLlRleHQ+XHJcbiAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDwvUm93PlxyXG5cclxuICAgICAgICA8Rm9ybS5Hcm91cCBjb250cm9sSWQ9XCJoaWdobGlnaHRcIiBjbGFzc05hbWU9XCJtYi0zXCI+XHJcbiAgICAgICAgICA8Rm9ybS5DaGVja1xyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBsYWJlbD1cIkhpZ2hsaWdodGVkXCJcclxuICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiaXNIaWdobGlnaHRcIil9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRm9ybS5Hcm91cD5cclxuXHJcbiAgICAgICAgPEZvcm0uR3JvdXAgY29udHJvbElkPVwib25WaWV3XCIgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgPEZvcm0uQ2hlY2tcclxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgbGFiZWw9XCJDdXJyZW50bHkgb24gVmlld1wiXHJcbiAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImlzT25WaWV3XCIpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0Zvcm0uR3JvdXA+XHJcblxyXG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiB0eXBlPVwic3VibWl0XCI+XHJcbiAgICAgICAgICBTdWJtaXRcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9Gb3JtPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsidXNlUm91dGVyIiwidXNlRm9ybSIsIlJvdyIsIkNvbCIsIkZvcm0iLCJCdXR0b24iLCJBZHZhbmNlZFNlYXJjaCIsInJvdXRlciIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0Iiwib25TdWJtaXQiLCJkYXRhIiwicXVlcnlTdHJpbmciLCJzZWFyY2hCeSIsInEiLCJnZW9Mb2NhdGlvbiIsIm1lZGl1bSIsImlzT25WaWV3IiwiaXNIaWdobGlnaHQiLCJwdXNoIiwiZGl2IiwiY2xhc3NOYW1lIiwiaDIiLCJHcm91cCIsImNvbnRyb2xJZCIsIkxhYmVsIiwiQ29udHJvbCIsInR5cGUiLCJwbGFjZWhvbGRlciIsInJlcXVpcmVkIiwiU2VsZWN0Iiwib3B0aW9uIiwidmFsdWUiLCJUZXh0IiwiQ2hlY2siLCJsYWJlbCIsInZhcmlhbnQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/search.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useIsomorphicEffect":
/*!*****************************************************!*\
  !*** external "@restart/hooks/useIsomorphicEffect" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useIsomorphicEffect");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Button":
/*!*************************************!*\
  !*** external "@restart/ui/Button" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Button");

/***/ }),

/***/ "@restart/ui/Dropdown":
/*!***************************************!*\
  !*** external "@restart/ui/Dropdown" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Dropdown");

/***/ }),

/***/ "@restart/ui/DropdownContext":
/*!**********************************************!*\
  !*** external "@restart/ui/DropdownContext" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownContext");

/***/ }),

/***/ "@restart/ui/DropdownItem":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownItem" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownItem");

/***/ }),

/***/ "@restart/ui/DropdownMenu":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownMenu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownMenu");

/***/ }),

/***/ "@restart/ui/DropdownToggle":
/*!*********************************************!*\
  !*** external "@restart/ui/DropdownToggle" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownToggle");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "@restart/ui/utils":
/*!************************************!*\
  !*** external "@restart/ui/utils" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/utils");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "invariant":
/*!****************************!*\
  !*** external "invariant" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("invariant");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "prop-types-extra/lib/all":
/*!*******************************************!*\
  !*** external "prop-types-extra/lib/all" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types-extra/lib/all");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "warning":
/*!**************************!*\
  !*** external "warning" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("warning");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "react-hook-form":
/*!**********************************!*\
  !*** external "react-hook-form" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap","vendor-chunks/bootstrap"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Fsearch&preferredRegion=&absolutePagePath=.%2Fpages%5Csearch.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();